# Telegram Auto Forward Bot (Bots.Business Compatible)

✅ Auto-forwards posts from a private channel to a public/target channel.

## How to Use on Bots.Business

1. Upload the project files.
2. Go to Bot Settings > Environment Variables and add:

```
BOT_TOKEN=123456:ABC-Your-Bot-Token
SOURCE_CHANNEL_ID=-100xxxxxxxxxx
TARGET_CHANNEL_ID=-100yyyyyyyyyy
```

3. Make sure your bot is admin in both channels.
4. Set main file as `index.js`
5. Click “Run Bot” — you're done 🎉
